if __name__ == '__main__':
    number = input('Silahkan masukan angka angka berapapun: ')
    exponent = int(number)**2
    print (f'kuadrat dari {number} = {exponent}')

