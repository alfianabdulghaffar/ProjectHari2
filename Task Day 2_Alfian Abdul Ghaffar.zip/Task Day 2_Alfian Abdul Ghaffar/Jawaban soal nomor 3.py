if __name__ == '__main__':
    x = 365
    tahun = x//360
    modTahun = x%360
    bulan = modTahun//30
    modBulan = modTahun%30
    hari=modTahun

    print (x,'hari adalah',tahun,"tahun,",bulan,"bulan",hari,"hari")