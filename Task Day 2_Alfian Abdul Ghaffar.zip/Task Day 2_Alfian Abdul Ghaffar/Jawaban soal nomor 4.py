if __name__ == '__main__':
    #x = andi
    #y = budi
    #x+y=49
    #x/y=0.4
    #x=0.4*y
    #(0.4*y)+y = 49
    #1.4*y=49
    y=49/1.4
    x = 49-y
    print ('umur andi 2 lagi adalah ', x + 2 )
    print ('umur budi 2 lagi adalah ', y + 2 )